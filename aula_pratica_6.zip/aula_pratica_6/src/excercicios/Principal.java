package excercicios;

public class Principal {
	
	public static void main(String[] args) {
	
		ContaCorrente a1 = new ContaCorrente("Daniel Rausch Dias", 100);
		ContaCorrente a2 = new ContaCorrente("Rafael Rausch Dias", 200);
	
		a1.depositar();
		a1.sacar();
		a1.transferir(a2);
		
		a1.info();
		a2.info();
	}
}
