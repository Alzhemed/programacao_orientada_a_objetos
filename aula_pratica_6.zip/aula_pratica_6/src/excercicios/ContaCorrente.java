package excercicios;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ContaCorrente {
	Scanner teclado = new Scanner(System.in);
	String nome;
	double saldo;
	
	public ContaCorrente(String nome, double saldo) {
		this.nome = nome;
		this.saldo = saldo;
	}

	public void depositar()  {
		double d;
		boolean exito = false;
		
		while (exito == false) {
			try {
				System.out.print("Digite o valor do deposito: ");
				d = teclado.nextDouble();
				if (d < 0) {
					throw new ValorInvalidoException(d, "Voce digitou um valor negativo, favor tentar novamente.");
				}
				saldo += d;
				exito = true;
			} catch (ValorInvalidoException e) {
				System.out.println(e.getMensagem());
			} catch (InputMismatchException i) {
				System.out.println("Voce digitou um valor nao numerico, favor tentar novamente.");
				teclado.nextLine();
			}
		}
	}
	
	public void sacar() {
		double d;
		boolean exito = false;
		
		while (exito == false) {
			try {
				System.out.print("Digite o valor do saque: ");
				d = teclado.nextDouble();
				if (d < 0) {
					throw new ValorInvalidoException(d, "Voce digitou um valor negativo, favor tentar novamente.");
				} else if (d > saldo) {
					throw new ValorInvalidoException(d, "Voce digitou um valor maior que seu saldo, favor tentar novamente.");
				}
				saldo -= d;
				exito = true;
			} catch (ValorInvalidoException e) {
				System.out.println(e.getMensagem());
			} catch (InputMismatchException i) {
				System.out.println("Voce digitou um valor nao numerico, favor tentar novamente.");
				teclado.nextLine();
			}
		}
	}
	
	public void transferir(ContaCorrente c) {
		double d;
		boolean exito = false;
		
		while (exito == false) {
			try {
				System.out.print("Digite o valor da transferencia: ");
				d = teclado.nextDouble();
				if (d < 0) {
					throw new ValorInvalidoException(d, "Voce digitou um valor negativo, favor tentar novamente.");
				} else if (d > saldo) {
					throw new ValorInvalidoException(d, "Voce digitou um valor maior que seu saldo, favor tentar novamente.");
				}
				saldo -= d;
				c.saldo += d;
				exito = true;
			} catch (InputMismatchException i) {
				System.out.println("Voce digitou um valor nao numerico, favor tentar novamente.");
				teclado.nextLine();
			} catch (ValorInvalidoException e) {
				System.out.println(e.getMensagem());
			}
		}
	}
	
	public void info() {
		System.out.println("Nome: " + nome);
		System.out.printf("Saldo: R$%.2f", saldo);
		System.out.println();
	}
}
