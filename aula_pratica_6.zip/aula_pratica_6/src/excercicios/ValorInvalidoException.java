package excercicios;

public class ValorInvalidoException extends Exception {
	private double valor;
	private String mensagem;
	public ValorInvalidoException(double valor, String mensagem) {
		this.valor = valor;
		this.mensagem = mensagem;
	}
	
	public String getMensagem() {
		return mensagem;
	}

	public double getValor() {
		return valor;
	}
	
	
}
