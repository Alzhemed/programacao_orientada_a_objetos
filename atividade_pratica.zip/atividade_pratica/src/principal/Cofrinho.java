package principal;

import java.util.ArrayList;
import java.util.HashMap;

public class Cofrinho {
	private ArrayList<Moeda> listaMoedas = new ArrayList<>();
	enum tipos{
		DOLAR,
		EURO,
		REAL
	}
	private HashMap<Enum, Double> tabelaConversao = new HashMap<>();
	
	public void atualizarConversao() {
		tabelaConversao.put(tipos.DOLAR, 5.7);
	}
	
	public void adicionar(Moeda m) {
		listaMoedas.add(m);
	}
	
	public void remover(Moeda m) {
		listaMoedas.remove(m);
	}
	
	public void listagemMoedas() {
		for (Moeda i: listaMoedas) {
			System.out.println("Nome: " + i.toString());
			System.out.println("Valor: " + i.valor);
		}
	}
	
	public void totalConvertido() {
		double valorTotalConvertido;
		for (Moeda i: listaMoedas) {
			
		}
	}
}
