package principal;

import java.util.ArrayList;

public class Cofrinho {
	//Estrutura de dados para armazenar as moedas do cofre
	private ArrayList<Moeda> listaMoedas = new ArrayList<Moeda>();
	
	//Método para adicionar moedas ao cofre
	public void adicionar(Moeda m) {
		listaMoedas.add(m);
	}
	
	//Método para remover moedas do cofre
	public void remover(Double v, String n) {
		//O método consiste em pecorrer pela lista de moedas e verificar se o valor e nome da classe são iguais aos do parâmetro.
		//Se forem, a moeda é removida da lista.
		String nome;
		for (Moeda m: listaMoedas) {
			nome = m.getClass().getSimpleName();
			if (m.valor == v && nome.equalsIgnoreCase(n)) {
				
				listaMoedas.remove(m);
				break;
			}
		}
	}
	//Método para listar as moedas, percorre a lista e para cada item executa o método info para retornar o nome da moeda e o valor
	public void listagemMoedas() {
		for (Moeda m: listaMoedas) {
			m.info();
		}
	}
	
	public void contarMoedas() {
		System.out.println("Quantidade de moedas no cofrinho: " + listaMoedas.size());
	}
	//Método para calcular o total convertido para real de todas as moedas no cofre, utilizar o método converter para cada item da lista
	public double totalConvertido() {
		double valorTotalConvertido = 0;
		for (Moeda m: listaMoedas) {
			valorTotalConvertido += m.converter();
		}
		
		return valorTotalConvertido;
	}
}
