package principal;

import java.util.ArrayList;
import java.util.HashMap;

public class Cofrinho {
	private ArrayList<Moeda> listaMoedas = new ArrayList<>();
	
	public void adicionar(Moeda m) {
		listaMoedas.add(m);
	}
	
	public void remover(Moeda m) {
		listaMoedas.remove(m);
	}
	
	public void listagemMoedas() {
		for (Moeda i: listaMoedas) {
			System.out.println(i.getDigitoIdentificador() + i.valor);
		}
	}
	
	public double totalConvertido() {
		double valorTotalConvertido = 0;
		for (Moeda i: listaMoedas) {
			valorTotalConvertido += i.converter();
		}
		
		return valorTotalConvertido;
	}
}
