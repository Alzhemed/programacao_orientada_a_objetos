package principal;

public abstract class Moeda {
	private static double taxaDeConversaoReal;
	private static char digitoIdentificador;
	private static int quantidade;
	double valor;
	
	public Moeda(double valor, char digitoIdentificador) {
		this.valor = valor;
		if (quantidade == 1) {
			this.digitoIdentificador = digitoIdentificador;
		}
	}
	
	public static char getDigitoIdentificador() {
		return digitoIdentificador;
	}

	public static void setDigitoIdentificador(char digitoIdentificador) {
		Moeda.digitoIdentificador = digitoIdentificador;
	}

	public static void atualizarConversao(double v) {
		taxaDeConversaoReal = v;
	}
	
	public double converter() {
		return valor*taxaDeConversaoReal;
	}
	
	public void info() {
		System.out.printf("Valor: ", digitoIdentificador, "%.2f", valor);
		System.out.println();
		System.out.printf("Taxa de conversao: %.2f", taxaDeConversaoReal);
		System.out.println();
		System.out.printf("Valor convertido: %.2f", converter());
	}
	
	
}
