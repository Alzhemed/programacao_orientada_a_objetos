package principal;

public abstract class Moeda {
	double valor;
	
	public void converter() {
		
	}
	
	public void info() {
		
	}
	
	
}
