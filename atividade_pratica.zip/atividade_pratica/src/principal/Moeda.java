package principal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;



public abstract class Moeda {
	//Classe mãe das moedas
	//A lista digitosIdentificadores serve para armazenar os dígitos que são utilizados para representar as moedas por extenso, por exemplo U$5,00
	//Além disso são usados como chave no HashMap taxasConversaoReal para armazenar as taxas de conversão para real de cada moeda
	//Foi criado dessa forma para que caso o usuário deseje, ele possa atualizar a conversão de cada moeda, visto que as cotações mudam todos os dias
	public static final ArrayList<String> digitosIdentificadores = new ArrayList<String>(List.of("U$", "R$", "€"));
	private static HashMap<String, Double> taxasDeConversaoReal = new HashMap<String, Double>();
	//
	double valor;
	public Moeda(double valor) {
		this.valor = valor;

	}
	//Método para atualizar a taxa de conversão de uma moeda
	public static void setTaxaDeConversao(String d, double v) {
		taxasDeConversaoReal.put(d, v);
	}
	
	//Método para obter a taxa de conversão de uma moeda
	public static double getTaxaDeConversao(String c) {
		return taxasDeConversaoReal.get(c);
	}
	

	public abstract double converter();
	
	public abstract void info();
	
	
}
