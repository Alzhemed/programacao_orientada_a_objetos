package principal;

public class Euro extends Moeda {
	public Euro(double valor) {
		super(valor);
	}
	
	//Tanto no método converter, quanto no info, são utilizados a lista digitosIdentificadores 
	//para obter o dígito que é utilizado ao representar os valores de uma moeda.
	public double converter() {
		return valor*Moeda.getTaxaDeConversao(Moeda.digitosIdentificadores.get(2));
	}
	
	public void info() {
		System.out.printf("Euro - %s%.2f %n", Moeda.digitosIdentificadores.get(2), valor);
	}
	
}
