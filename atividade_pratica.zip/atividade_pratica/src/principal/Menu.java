package principal;

public class Menu {
	//Classe para facilitar a escrita do menu da tela de opções
	public static void imprimirMenu() {
		System.out.println("COFRINHO: ");
		System.out.println("1 - Adicionar moeda ");
		System.out.println("2 - Remover moeda");
		System.out.println("3 - Listar moedas");
		System.out.println("4 - Contar moedas");
		System.out.println("5 - Calcular total convertido para real");
		System.out.println("6 - Alterar taxa de conversao");
		System.out.println("0 - Encerrar");
	}
	
	public static void imprimirOpcoesMoedas() {
		System.out.println("Escolha a moeda: ");
		System.out.println("1 - Real");
		System.out.println("2 - Dolar");
		System.out.println("3 - Euro");
	}
}
