package principal;

public class Principal {

	public static void main(String[] args) {
		Cofrinho c = new Cofrinho();
		Dolar.atualizarConversao(5.33);
		c.adicionar(new Dolar(2.5, '$'));
		c.adicionar(new Dolar(3, '$'));
		c.adicionar(new Dolar(5, '$'));
		
		
		c.listagemMoedas();
		System.out.printf("Valor total no cofrinho: R$%.2f", c.totalConvertido());
		
	}

}
