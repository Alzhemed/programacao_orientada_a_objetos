package principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int controle = 5;
		//No classe Principal é instanciado o cofrinho e atualizadas as taxas para um valor padrão antes do loop iniciar
		//Caso o usuário deseje, durante a execução é possível atualizar essas taxas
		Cofrinho c = new Cofrinho();
		Moeda.setTaxaDeConversao(Moeda.digitosIdentificadores.get(0), 5.29);
		Moeda.setTaxaDeConversao(Moeda.digitosIdentificadores.get(2), 5.27);
		//O loop será mantido até que o usuário deseje encerrar
		while (controle != 0) {
			//Bloco try e blocos try menores dentro de cada case para garantir que o usuário não digite um valor diferente de um número
			//E que o programa seja encerrado.
			try {
				//O menu é impresso e o usuário escolhe uma opção
				Menu.imprimirMenu();
				controle = teclado.nextInt();
				//Estrutura de controle para que seja escolhida uma opção que o usuário deseja interagir
				switch (controle) {
				//Adicionar moedas
				case 1:
					try {
						Menu.imprimirOpcoesMoedas();
						controle = teclado.nextInt();
						switch (controle) {
						case 1: 
							System.out.println("Digite o valor: ");
							c.adicionar(new Real(teclado.nextDouble()));
							break;
						case 2: 
							System.out.println("Digite o valor: ");
							c.adicionar(new Dolar(teclado.nextDouble()));
							break;
						case 3: 
							System.out.println("Digite o valor: ");
							c.adicionar(new Euro(teclado.nextDouble()));
							break;
						}
					} catch (InputMismatchException e) {
						System.out.println("Você digitou um valor não numérico, favor digitar apenas números.");
						teclado.nextLine();
						continue;
					}
					break;
				//Remover moedas
				case 2:
					try {
						Menu.imprimirOpcoesMoedas();
						controle = teclado.nextInt();
						switch (controle) {
						case 1: 
							System.out.println("Digite o valor: ");
							c.remover(teclado.nextDouble(), "Real");
							break;
						case 2: 
							System.out.println("Digite o valor: ");
							c.remover(teclado.nextDouble(), "Dolar");
							break;
						case 3: 
							System.out.println("Digite o valor: ");
							c.remover(teclado.nextDouble(), "Euro");
							break;
						}
					} catch (InputMismatchException e) {
						System.out.println("Você digitou um valor não numérico, favor digitar apenas números.");
						teclado.nextLine();
						continue;
					}
					break;
				//Listar as moedas no cofrinho
				case 3:
					c.listagemMoedas();
					break;
				//Mostra a quantidade de moedas no cofrinho
				case 4:
					c.contarMoedas();
					break;
				//Mostra o valor total convertido para real das moedas no cofrinho
				case 5:
					System.out.printf("Valor total convertido em real: R$%.2f %n", c.totalConvertido());
					break;
				//Permite ao usuário alterar a taxa de conversão das moedas
				case 6:
					try {
						System.out.println("Escolha a moeda: ");
						System.out.println("1 - Dolar");
						System.out.println("2 - Euro");
						controle = teclado.nextInt();
						switch (controle) {
						case 1:
							System.out.println("Digite o valor: ");
							Moeda.setTaxaDeConversao(Moeda.digitosIdentificadores.get(0), teclado.nextDouble());
							break;
						case 2:
							System.out.println("Digite o valor: ");
							Moeda.setTaxaDeConversao(Moeda.digitosIdentificadores.get(2), teclado.nextDouble());
							break;
						}
					} catch (InputMismatchException e) {
						System.out.println("Você digitou um valor não numérico, favor digitar apenas números.");
						teclado.nextLine();
						continue;
					}
				case 0:
					break;
				} 
			} catch (InputMismatchException e) {
				System.out.println("Você digitou um valor diferente de um inteiro, favor tentar novamente.");
				teclado.nextLine();
				continue;
				}
		
		}
		
	}

}
