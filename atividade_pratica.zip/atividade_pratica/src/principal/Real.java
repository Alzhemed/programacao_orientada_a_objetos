package principal;

public class Real extends Moeda {
	public Real(double valor) {
		super(valor);

	}
	
	//Tanto no método converter, quanto no info, são utilizados a lista digitosIdentificadores 
	//para obter o dígito que é utilizado ao representar os valores de uma moeda.
	public double converter() {
		return valor;
	}
	
	public void info() {
		System.out.printf("Real - %s%.2f %n", Moeda.digitosIdentificadores.get(1), valor);
	}

}
