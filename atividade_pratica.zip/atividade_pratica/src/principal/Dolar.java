package principal;

public class Dolar extends Moeda {
	public Dolar(double valor) {
		super(valor);
	}
	
	//Tanto no método converter, quanto no info, são utilizados a lista digitosIdentificadores 
	//para obter o dígito que é utilizado ao representar os valores de uma moeda.
	public double converter() {
		return valor*Moeda.getTaxaDeConversao(Moeda.digitosIdentificadores.get(0));
	}
	
	public void info() {
		System.out.printf("Dolar - %s%.2f %n", Moeda.digitosIdentificadores.get(0), valor);
	}
	
}
