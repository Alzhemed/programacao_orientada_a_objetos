package exercicios;

public class Principal {

	public static void main(String[] args) {
		
		Cofrinho c = new Cofrinho();
		
		c.adicionar(new Moeda(1, "1 Real"));
		c.adicionar(new Moeda(0.50, "50 centavos"));
		c.adicionar(new Moeda(0.25, "25 centavos"));
	}

}
