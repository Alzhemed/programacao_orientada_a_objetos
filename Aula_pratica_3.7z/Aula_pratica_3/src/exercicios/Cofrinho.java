package exercicios;

import java.util.ArrayList;
import java.util.Iterator;

public class Cofrinho {
	private ArrayList<Moeda> moedas = new ArrayList<Moeda>();
	
	public Cofrinho() {
		
	}
	
	public int getQuantidadeDeMoedas() {
		return moedas.size();
	}
	
	public void adicionar(Moeda m) {
		moedas.add(m);
	}
	
	public double calcularTotal() {
		double valorTotal = 0;
		Iterator<Moeda> it = moedas.iterator();
		
		while(it.hasNext()) {
			valorTotal += it.next().getValor();
		}
		
		return valorTotal;
	}
	
}
