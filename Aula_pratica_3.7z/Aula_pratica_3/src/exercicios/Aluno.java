package exercicios;

public class Aluno {
	String nome;
	private int matricula;
	double desconto;
	Curso curso;
	
	public Aluno(String nome, int matricula, double desconto, Curso curso) {
		this.nome = nome;
		this.matricula = matricula;
		this.desconto = desconto;
		this.curso = curso;
	}

	public void info() {
		System.out.println("Nome do aluno: " + nome);
		System.out.println("Matricula: " + matricula);
		System.out.printf("Desconto: %.2f", desconto);
		System.out.print("%");
		System.out.println();
		curso.info();
		
	}
	
	public void pagamento() {
		double preco = curso.mensalidade - curso.mensalidade*(desconto/100);
		
		System.out.printf("O valor da mensalidade do aluno com desconto e: R$%.2f", preco);
	}
	
}
