package exercicios;

public class Principal {
	public static void main(String[] args) {
		IngressoVip i = new IngressoVip("Rock in Rio", 750, 250);
		
		i.imprimir();
	}
}
