package exercicios;

public class IngressoVip extends Ingresso {
	double adicional;
	
	public IngressoVip(String nomeEvento, double valor, double adicional) {
		super(nomeEvento, valor);
		this.adicional = adicional;
	}

	@Override
	public void imprimir() {
		super.imprimir();
		System.out.println("Valor adicional VIP: " + adicional);
		System.out.println("Valor total: " + (adicional+valor));
	}
	
}
