package exercicios;

public class Ingresso {
	
	public String nomeEvento;
	public double valor;
	
	Ingresso(String nomeEvento, double valor) {
		this.nomeEvento = nomeEvento;
		this.valor = valor;
	}
	
	public void imprimir() {
		System.out.println("Evento: " + nomeEvento);
		System.out.println("Valor do ingresso: " + valor);
	}
}
