package aula_teorica_5;

import java.util.Scanner;

public class Quadrado extends FormaGeometrica {

	@Override
	public void calculaArea() {
		Scanner teclado = new Scanner(System.in);
		System.out.print("Digite o tamanho do lado do quadrado: ");
		double lado = teclado.nextDouble();
		area = Math.pow(lado, 2);
		System.out.println("A area do quadrado e: " + area);
	}

}
