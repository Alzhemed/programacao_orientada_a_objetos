package aula_teorica_5;

public interface Animal {
	
	
	public void emitirSom();
	
	public void dormir();
}
