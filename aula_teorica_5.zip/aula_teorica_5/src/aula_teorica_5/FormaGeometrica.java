package aula_teorica_5;

public abstract class FormaGeometrica {
	public double area;
	
	public abstract void calculaArea();
}
