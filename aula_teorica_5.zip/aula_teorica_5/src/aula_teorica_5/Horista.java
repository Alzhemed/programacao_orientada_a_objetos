package aula_teorica_5;

public class Horista extends Funcionario {
	int totalHoras;
	float valorHora;
	
	public Horista(String nome, float valorHora, int totalHoras) {
		super(nome);
		this.valorHora = valorHora;
		this.totalHoras = totalHoras;
	}
	
	public float pagamento() {
		return totalHoras*valorHora;
	}
	
}
