package aula_teorica_5;

public class Gato implements Animal{
	
	@Override
	public void emitirSom() {
		System.out.println("Miau!");
	}
	
	@Override
	public void dormir() {
		System.out.println("ZzzzZzzz...");
	}
}
