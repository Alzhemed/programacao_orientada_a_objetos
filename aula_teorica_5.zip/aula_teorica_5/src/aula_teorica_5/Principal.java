package aula_teorica_5;

public class Principal {

	public static void main(String[] args) {
		Roupa n = new Roupa("Moletom", 40, Estacao.INVERNO);
		
		n.msg();
	}

}
