package aula_teorica_5;

import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {
		ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
		
		funcionarios.add(new Assalariado("Daniel", 1700));
		funcionarios.add(new Comissionado("Gabriel", 0.05f, 50000));
		funcionarios.add(new Horista("Rafael", 40.5f, 100));

		float total = 0;
		for (Funcionario i : funcionarios) {
			total += i.pagamento();
			System.out.println("Nome: " + i.nome);
			System.out.println("Salario: " + i.pagamento());
		}
		System.out.println("Pagamento total de salarios: " + total);
	}

}
